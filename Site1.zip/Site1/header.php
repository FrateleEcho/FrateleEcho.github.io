<?php
    $document = JFactory::getDocument();
?>
    <header class="u-clearfix u-header u-header" id="sec-fce5">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1">
    <?php $logoInfo = getLogoInfo(array(
            'src' => "/images/images.jpg",
            'href' => "https://discord.gg/86gzmJqrv6",
        ), true); ?><a href="<?php echo $logoInfo['href']; ?>" class="u-image u-logo u-image-1" data-image-width="225" data-image-height="225" title="Server">
      <img src="<?php echo $logoInfo['src']; ?>" class="u-logo-image u-logo-image-1">
    </a>
  </div>
</header>
    