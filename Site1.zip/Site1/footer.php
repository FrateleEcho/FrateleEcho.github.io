<?php
    $document = JFactory::getDocument();
?>
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-0a24">
  <div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1">This site is just for testing out smh.&nbsp;</p>
  </div>
</footer>
    