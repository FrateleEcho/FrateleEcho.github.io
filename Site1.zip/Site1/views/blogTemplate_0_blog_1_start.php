<?php ob_start(); ?>
<section class="u-clearfix u-section-1" id="sec-cefb">
  <div class="u-clearfix u-sheet u-valign-middle u-sheet-1"><?php
$blogJson = '{"type":"Recent","source":"","tags":"","count":""}';
if ($all) { echo getGridAutoRowsStyles($blogJson, $all); }
?>

    <div class="u-blog u-expanded-width u-repeater u-repeater-1">